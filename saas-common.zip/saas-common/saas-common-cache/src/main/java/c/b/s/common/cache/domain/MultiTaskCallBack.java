package c.b.s.common.cache.domain;

/**
 * Created by guiqingqing on 2018/11/17.
 */
public interface MultiTaskCallBack {
    void execute(Object resource);
}