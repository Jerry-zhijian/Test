package c.p.b.api.request;

import java.io.Serializable;

/**
 * Base request.
 * <p>
 * Created: 2018-08-01 14:59:09
 *
 * @author Michael.Zhang
 */
public abstract class Request implements Serializable {

}