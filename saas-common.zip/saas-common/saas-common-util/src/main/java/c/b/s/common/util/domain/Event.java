package c.b.s.common.util.domain;

import java.io.Serializable;

/**
 * 领域事件。
 * 
 * Created: 2018-05-22 10:27:05
 * @version 1.0.0
 * @author  Michael.Zhang
 */
public class Event implements Serializable {
    
}
