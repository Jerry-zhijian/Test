package c.b.s.common.util.domain;

import java.io.Serializable;

/**
 * 值对象。
 *
 * Created: 2018-05-22 09:48:46
 * @version 1.0.0
 * @author  Michael.Zhang
 */
public class ValueObject implements Serializable {
    
}
