package c.b.s.common.util.domain;

/**
 * 
 * 
 * Created: 2018-05-22 15:48:25
 * 
 * @author  Michael.Zhang
 */
public class AggregateRoot extends Entity {
    
}
