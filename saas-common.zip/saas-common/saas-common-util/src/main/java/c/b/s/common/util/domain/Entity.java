package c.b.s.common.util.domain;

/**
 * 实体。
 *
 * Created: 2018-05-22 09:42:29
 * @version 1.0.0
 * @author  Michael.Zhang
 */
public class Entity extends IdentifiedDomainObject {
    
}
