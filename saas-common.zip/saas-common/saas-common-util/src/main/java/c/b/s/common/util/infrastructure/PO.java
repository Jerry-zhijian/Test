package c.b.s.common.util.infrastructure;

import java.io.Serializable;

/**
 * Created: 2018-05-22 15:12:11
 * 
 * @author  Michael.Zhang
 */
public class PO implements Serializable {
    
}
