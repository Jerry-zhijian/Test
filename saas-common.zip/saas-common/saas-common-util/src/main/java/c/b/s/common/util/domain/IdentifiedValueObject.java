package c.b.s.common.util.domain;

/**
 * 
 * 
 * Created: 2018-05-22 21:37:44
 * 
 * @author  Michael.Zhang
 */
public abstract class IdentifiedValueObject extends IdentifiedDomainObject {
    
}
