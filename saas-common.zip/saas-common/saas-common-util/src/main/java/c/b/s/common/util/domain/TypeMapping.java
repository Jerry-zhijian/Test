package c.b.s.common.util.domain;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by guiqingqing on 2019/7/18.
 */
@Data
@NoArgsConstructor
public class TypeMapping {
    private String original;
    private String mapping;
}