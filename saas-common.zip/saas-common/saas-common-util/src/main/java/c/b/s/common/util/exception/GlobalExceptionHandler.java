package c.b.s.common.util.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;

/**
 * @Author: lingjie
 * @Date: 2018/8/2 20:34
 * 全局异常处理类
 */
@ControllerAdvice
public class GlobalExceptionHandler {

}
